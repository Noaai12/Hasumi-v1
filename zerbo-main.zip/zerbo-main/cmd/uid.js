module.exports = {
    name: "uid",
    aliases: ["userid"],
    description: "Get user ID - use /uid or reply to someone's message with /uid",
    usage: "/uid [reply to message]",
    author: "Edinst",
    cooldown: 5,
    role: 0,
    execute: async function(api, event, args) {
        try {
            // If replying to someone's message
            if (event.isReply && event.replySenderID) {
                return api.sendMessage(
                    `🆔 User ID dari pesan yang direply:\n` +
                    `${event.replySenderID}`,
                    event.threadID
                );
            }
            
            // If no reply, show own ID
            return api.sendMessage(
                `🆔 User ID kamu:\n` +
                `${event.senderID}`, 
                event.threadID
            );

        } catch (error) {
            console.error("Error in uid command:", error);
            api.sendMessage(
                "❌ Gagal mengambil User ID", 
                event.threadID
            );
        }
    }
};
