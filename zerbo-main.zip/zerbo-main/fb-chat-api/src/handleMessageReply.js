module.exports = function(defaultFuncs, api, ctx) {
    return function messageReplyHandler(event) {
        if (!event.messageReply) {
            event.isReply = false;
            return event;
        }

        try {
            event.isReply = true;
            event.replyMessageID = event.messageReply.messageID;
            event.replySenderID = event.messageReply.senderID;
            event.replyBody = event.messageReply.body;

            // Check if user is replying to themselves
            event.isSelfReply = event.senderID === event.replySenderID;

            // Add metadata about the reply
            event.replyMetadata = {
                timestamp: event.messageReply.timestamp,
                attachments: event.messageReply.attachments || [],
                participantIDs: event.messageReply.participantIDs || [],
                isGroup: event.messageReply.isGroup || false
            };

            // Validate required fields
            if (!event.replySenderID) {
                console.error("Warning: Reply message missing senderID");
                event.isValidReply = false;
            } else {
                event.isValidReply = true;
            }

            return event;

        } catch (error) {
            console.error("Error in handleMessageReply:", error);
            event.isReply = false;
            event.isValidReply = false;
            return event;
        }
    };
};
